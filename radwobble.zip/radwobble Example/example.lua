vanilla_model.ALL:visible(false)
local radwobble = require("radwobble")

--create new effect
radwobble.new(models.model, .8, 1, .2, {"bone"})

--get player velocity and adjust to match player rotation, and apply-
--velocity * 16 (worldspace) and scaling based on crouch state
function events.tick()
	local vel = vectors.rotateAroundAxis((player:getRot().y + 180) % 360 - 180, player:getVelocity(), vec(0, 1, 0))
	radwobble.applyFunc(models.model, vec(0, -2, 0), .2, function(_, anchor) 
		return (vel * 16) + (player:isCrouching() and anchor * vec(-1, 1, -1) or 0)
	end)
end