vanilla_model.PLAYER:setVisible(false)
local radwobble = require("radwobble")
radwobble.new(models.model, .8, 1, .2)

function events.tick()
	radwobble.apply(models.model, vec(0, 8, 0), player:getVelocity() * -16)
end