vanilla_model.PLAYER:setVisible(false)
local radwobble = require("radwobble")
radwobble.new(models.model, .8, 1, .2)

--purely visual
local tex = textures:fromVanilla("", "textures/entity/slime/slime.png")
models.model:setPrimaryTexture("CUSTOM", tex)
	:setUVMatrix(matrices.scale3(.5, 1, 0))

--apply physics to models.model, with a centerpoint and force based on the player's velocity
function events.tick()
	radwobble.apply(models.model, vec(0, 4, 0) + player:getVelocity() * 16, player:getVelocity() * 256)
end